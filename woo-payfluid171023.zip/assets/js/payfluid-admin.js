jQuery(function ($) {
    'use strict';

    /**
     * Object to handle Payfluid admin functions.
     */
    var wc_payfluid_admin = {
        /**
         * Initialize.
         */
        init: function () {

            // Toggle api key settings.
            $(document.body).on('change', '#woocommerce_payfluid_testmode', function () {
                var test_api_key = $('#woocommerce_payfluid_test_api_key').parents('tr').eq(0),
                        test_public_key = $('#woocommerce_payfluid_test_public_key').parents('tr').eq(0),
                        live_api_key = $('#woocommerce_payfluid_live_api_key').parents('tr').eq(0),
                        live_public_key = $('#woocommerce_payfluid_live_public_key').parents('tr').eq(0);
                        test_client_id = $('#woocommerce_payfluid_test_client_id').parents('tr').eq(0);
                        live_client_id = $('#woocommerce_payfluid_live_client_id').parents('tr').eq(0);

                if ($(this).is(':checked')) {
                    test_api_key.show();
                    test_public_key.show();
                    live_api_key.hide();
                    live_public_key.hide();
                    test_client_id.hide();
                    live_client_id.hide();
                } else {
                    test_api_key.hide();
                    test_public_key.hide();
                    live_api_key.show();
                    live_public_key.show();
                    test_client_id.show();
                    live_client_id.show();
                }
            });

            $('#woocommerce_payfluid_testmode').change();

            /*$(document.body).on('change', '.woocommerce_paystack_split_payment', function () {
                var subaccount_code = $('.woocommerce_paystack_subaccount_code').parents('tr').eq(0),
                        subaccount_charge = $('.woocommerce_paystack_split_payment_charge_account').parents('tr').eq(0),
                        transaction_charge = $('.woocommerce_paystack_split_payment_transaction_charge').parents('tr').eq(0);

                if ($(this).is(':checked')) {
                    subaccount_code.show();
                    subaccount_charge.show();
                    transaction_charge.show();
                } else {
                    subaccount_code.hide();
                    subaccount_charge.hide();
                    transaction_charge.hide();
                }
            });*/

            /*$('#woocommerce_paystack_split_payment').change();*/

            // Toggle Custom Metadata settings.
            $('.wc-payfluid-metadata').change(function () {
                if ($(this).is(':checked')) {
                    $('.wc-payfluid-meta-order-id, .wc-payfluid-meta-name, .wc-payfluid-meta-email, .wc-payfluid-meta-phone, .wc-payfluid-meta-billing-address, .wc-payfluid-meta-shipping-address, .wc-payfluid-meta-products').closest('tr').show();
                } else {
                    $('.wc-payfluid-meta-order-id, .wc-payfluid-meta-name, .wc-payfluid-meta-email, .wc-payfluid-meta-phone, .wc-payfluid-meta-billing-address, .wc-payfluid-meta-shipping-address, .wc-payfluid-meta-products').closest('tr').hide();
                }
            }).change();

            // Toggle Bank filters settings.
            /*$('.wc-payfluid-payment-channels').on('change', function () {

                var channels = $(".wc-payfluid-payment-channels").val();

                if ($.inArray('card', channels) != '-1') {
                    $('.wc-payfluid-cards-allowed').closest('tr').show();
                    $('.wc-payfluid-banks-allowed').closest('tr').show();
                } else {
                    $('.wc-payfluid-cards-allowed').closest('tr').hide();
                    $('.wc-payfluid-banks-allowed').closest('tr').hide();
                }

            }).change();*/

            $(".wc-payfluid-payment-icons").select2({
                templateResult: formatPayfluidPaymentIcons,
                templateSelection: formatPayfluidPaymentIcons
            });

        }
    };

    function formatPayfluidPaymentIcons(payment_method) {
        if (!payment_method.id) {
            return payment_method.text;
        }
        var $payment_method = $(
                '<span><img src=" ' + wc_payfluid_admin_params.plugin_url + '/assets/images/' + payment_method.element.value.toLowerCase() + '.png" class="img-flag" style="height: 15px; weight:18px;" /> ' + payment_method.text + '</span>'
                );
        return $payment_method;
    }
    ;

    wc_payfluid_admin.init();

});
