<?php

/**
 * Plugin Name: Payfluid WooCommerce Payment Gateway
 * Plugin URI: https://payfluid.herokuapp.com
 * Description: A WooCommerce payment gateway for payments via credit & debit cards, mobile wallet, bank accounts etc
 * Version: 1.0.0
 * Author: Taiwo Abiodun
 * Author URI: myrtle.oak.prime.technologies@gmail.com
 * WC requires at least: 3.0.0
 * WC tested up to: 4.0.0
 */
if (!defined('ABSPATH')) {
    exit;
}

define('WC_PAYFLUID_MAIN_FILE', __FILE__);
define('WC_PAYFLUID_URL', untrailingslashit(plugins_url('/', __FILE__)));

define('WC_PAYFLUID_VERSION', '1.0.0');
//define('WP_DEBUG', true);
//define('WP_DEBUG_LOG', true);

/**
 * Initialize Payfluid WooCommerce payment gateway.
 */
function moak_wc_payfluid_init() {

    if (!class_exists('WC_Payment_Gateway')) {
        add_action('admin_notices', 'moak_wc_payfluid_wc_missing_notice');
        return;
    }

    add_action('admin_notices', 'moak_wc_payfluid_testmode_notice');
    require_once dirname(__FILE__) . '/includes/class-wc-gateway-payfluid.php';
    require_once dirname(__FILE__) . '/includes/polyfill.php';
    add_filter('woocommerce_payment_gateways', 'moak_wc_add_payfluid_gateway', 99);

    add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'moak_woo_payfluid_plugin_action_links');
}

add_action('plugins_loaded', 'moak_wc_payfluid_init', 99);

/**
 * Add Settings link to the plugin entry in the plugins menu.
 *
 * @param array $links Plugin action links.
 *
 * @return array
 * */
function moak_woo_payfluid_plugin_action_links($links) {

    $settings_link = array(
        'settings' => '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=payfluid') . '" title="' . __('View Payfluid WooCommerce Settings', 'woo-payfluid') . '">' . __('Settings', 'woo-payfluid') . '</a>',
    );

    return array_merge($settings_link, $links);
}

/**
 * Add Payfluid Gateway to WooCommerce.
 *
 * @param array $methods WooCommerce payment gateways methods.
 *
 * @return array
 */
function moak_wc_add_payfluid_gateway($methods) {

    if (class_exists('WC_Payment_Gateway_CC')) {
        $methods[] = 'WC_Gateway_Payfluid';
    } else {
        $methods[] = 'WC_Gateway_Payfluid';
    }
    return $methods;
}

/**
 * Display a notice if WooCommerce is not installed
 */
function moak_wc_payfluid_wc_missing_notice() {
    echo '<div class="error"><p><strong>' . sprintf(__('Payfluid requires WooCommerce to be installed and active. Click %s to install WooCommerce.', 'woo-payfluid'), '<a href="' . admin_url('plugin-install.php?tab=plugin-information&plugin=woocommerce&TB_iframe=true&width=772&height=539') . '" class="thickbox open-plugin-details-modal">here</a>') . '</strong></p></div>';
}

/**
 * Display the test mode notice.
 * */
function moak_wc_payfluid_testmode_notice() {

    $payfluid_settings = get_option('woocommerce_payfluid_settings');
    $test_mode = isset($payfluid_settings['testmode']) ? $payfluid_settings['testmode'] : '';

    if ('yes' === $test_mode) {
        echo '<div class="update-nag">' . sprintf(__('Payfluid test mode is still enabled, Click <strong><a href="%s">here</a></strong> to disable it when you want to start accepting live payment on your site.', 'woo-payfluid'), esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=payfluid'))) . '</div>';
    }
}
