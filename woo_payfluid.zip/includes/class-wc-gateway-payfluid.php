<?php
//include('Crypt/RSA.php');
if (!defined('ABSPATH')) {
    exit;
}

class WC_Gateway_Payfluid extends WC_Payment_Gateway_CC {

    /**
     * Is test mode active?
     *
     * @var bool
     */
    public $testmode;

    /**
     * Payfluid payment page type.
     *
     * @var string
     */
    public $payment_page;

    /**
     * Payfluid test public key.
     *
     * @var string
     */
    public $test_public_key;

    /**
     * Payfluid test api key.
     *
     * @var string
     */
    public $test_api_key;

    /**
     * Payfluid client id.
     *
     * @var string
     */
    public $test_client_id;

    /**
     * Payfluid live public key.
     *
     * @var string
     */
    public $live_public_key;

    /**
     * Payfluid live api key.
     *
     * @var string
     */
    public $live_api_key;

    /**
     * Payfluid live client id.
     *
     * @var string
     */
    public $live_client_id;

    /**
     * Should we save customer cards?
     *
     * @var bool
     */
    /* public $saved_cards;

      /**
     * Should Payfluid split payment be enabled.
     *
     * @var bool
     *
      public $split_payment;

      /**
     * Payfluid sub account code.
     *
     * @var string
     *
      public $subaccount_code;

      /**
     * Who bears Payfluid charges?
     *
     * @var string
     *
      public $charges_account;

      /**
     * A flat fee to charge the sub account for each transaction.
     *
     * @var string
     *
      public $transaction_charges; */

    /**
     * Should custom metadata be enabled?
     *
     * @var bool
     */
    public $custom_metadata;

    /**
     * Should the order id be sent as a custom metadata to Payfluid?
     *
     * @var bool
     */
    public $meta_order_id;

    /**
     * Should the customer name be sent as a custom metadata to Payfluid?
     *
     * @var bool
     */
    public $meta_name;

    /**
     * Should the billing email be sent as a custom metadata to Payfluid?
     *
     * @var bool
     */
    public $meta_email;

    /**
     * Should the billing phone be sent as a custom metadata to Payfluid?
     *
     * @var bool
     */
    public $meta_phone;

    /**
     * Should the billing address be sent as a custom metadata to Payfluid?
     *
     * @var bool
     */
    public $meta_billing_address;

    /**
     * Should the shipping address be sent as a custom metadata to Payfluid?
     *
     * @var bool
     */
    public $meta_shipping_address;

    /**
     * Should the order items be sent as a custom metadata to Payfluid?
     *
     * @var bool
     */
    public $meta_products;

    /**
     * API public key
     *
     * @var string
     */
    public $public_key;

    /**
     * API secret key
     *
     * @var string
     */
    public $client_id;

    /**
     * Client Id
     *
     * @var string
     */
    public $test_pay_url;
    public $live_pay_url;
    public $pay_url;

    //public $pay_feedback_url;

    /**
     * Constructor
     */
    public function __construct() {
        $this->id = 'payfluid';
        $this->method_title = __('Payfluid', 'woo-payfluid');
        $this->method_description = sprintf(__('Payfluid provide merchants with services needed to accept online payments from local and international customers using Mastercard, Visa, Gh-link, Mobile Money Accounts and Bank Accounts.', 'woo-payfluid'));
        $this->has_fields = true;
        
        // Load the form fields
        $this->init_form_fields();

        // Load the settings
        $this->init_settings();

        // Get setting values
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');
        $this->testmode = $this->get_option('testmode') === 'yes' ? true : false;

        $this->payment_page = $this->get_option('payment_page');

        $this->test_public_key = $this->get_option('test_public_key');
        $this->test_api_key = $this->get_option('test_api_key');
        $this->test_client_id = $this->get_option('test_client_id');
        $this->test_pay_url = $this->get_option('test_pay_url');

        $this->live_public_key = $this->get_option('live_public_key');
        $this->live_api_key = $this->get_option('live_api_key');
        $this->live_client_id = $this->get_option('live_client_id');
        $this->live_pay_url = $this->get_option('live_pay_url');
        //$this->pay_feedback_url = $this->get_option('pay_feedback_url');

        $this->custom_metadata = $this->get_option('custom_metadata') === 'yes' ? true : false;

        $this->meta_order_id = $this->get_option('meta_order_id') === 'yes' ? true : false;
        $this->meta_name = $this->get_option('meta_name') === 'yes' ? true : false;
        $this->meta_email = $this->get_option('meta_email') === 'yes' ? true : false;
        $this->meta_phone = $this->get_option('meta_phone') === 'yes' ? true : false;
        $this->meta_billing_address = $this->get_option('meta_billing_address') === 'yes' ? true : false;
        $this->meta_shipping_address = $this->get_option('meta_shipping_address') === 'yes' ? true : false;
        $this->meta_products = $this->get_option('meta_products') === 'yes' ? true : false;

        $this->public_key = $this->testmode ? $this->test_public_key : $this->live_public_key;
        $this->api_key = $this->testmode ? $this->test_api_key : $this->live_api_key;
        $this->client_id = $this->testmode ? $this->test_client_id : $this->live_client_id;
        $this->pay_url = $this->testmode ? $this->test_pay_url : $this->live_pay_url;

        // Hooks
        add_action('wp_enqueue_scripts', array($this, 'payment_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));

        add_action('admin_notices', array($this, 'admin_notices'));
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options',));

        add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));

        // Payment listener/API hook.
        add_action('woocommerce_api_wc_gateway_payfluid', array($this, 'verify_payfluid_transaction'));

        // Webhook listener/API hook.
        add_action('woocommerce_api_moak_wc_payfluid_webhook', array($this, 'process_webhooks'));

        // Check if the gateway can be used.
        if (!$this->is_valid_for_use()) {
            $this->enabled = false;
        }
    }

    /**
     * Check if this gateway is enabled and available in the user's country.
     */
    public function is_valid_for_use() {

        if (!in_array(get_woocommerce_currency(), apply_filters('woocommerce_payfluid_supported_currencies', array('NGN', 'USD', 'GBP', 'GHS', 'GHC')))) {

            $this->msg = sprintf(__('Payfluid does not support your store currency. Kindly set it to either NGN (&#8358), GHS (&#x20b5;), USD (&#36;) or GBP (&#163;) <a href="%s">here</a>', 'woo-payfluid'), admin_url('admin.php?page=wc-settings&tab=general'));

            return false;
        }

        return true;
    }

    /**
     * Display payfluid payment icon.
     */
    public function get_icon() {

        //$icon = '<img src="' . WC_HTTPS::force_https_url(plugins_url('assets/images/payfluid.PNG', WC_PAYFLUID_MAIN_FILE)) . '" alt="payfluid" />';
        $icon = '<img src="' . WC_HTTPS::force_https_url(plugins_url('assets/images/pay_icon5.jpg', WC_PAYFLUID_MAIN_FILE)) . '" alt="payfluid" />';

        return apply_filters('woocommerce_gateway_icon', $icon, $this->id);
    }

    /**
     * Check if Payfluid merchant details is filled.
     */
    public function admin_notices() {

        if ($this->enabled == 'no') {
            return;
        }

        // Check required fields.
        if (!( $this->public_key && $this->api_key && $this->client_id )) {
            echo '<div class="error"><p>' . sprintf(__('Please enter your Payfluid merchant details <a href="%s">here</a> to be able to use the Payfluid WooCommerce plugin.', 'woo-payfluid'), admin_url('admin.php?page=wc-settings&tab=checkout&section=payfluid')) . '</p></div>';
            return;
        }
    }

    /**
     * Check if Payfluid gateway is enabled.
     *
     * @return bool
     */
    public function is_available() {

        if ('yes' == $this->enabled) {

            if (!( $this->public_key && $this->api_key && $this->client_id)) {

                return false;
            }

            return true;
        }

        return false;
    }

    /**
     * Admin Panel Options.
     */
    public function admin_options() {
        ?>

        <h2><?php _e('Payfluid', 'woo-payfluid'); ?>
            <?php
            if (function_exists('wc_back_link')) {
                wc_back_link(__('Return to payments', 'woo-payfluid'), admin_url('admin.php?page=wc-settings&tab=checkout'));
            }
            ?>
        </h2>

        <?php
        if ($this->is_valid_for_use()) {

            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
        } else {
            ?>
            <div class="inline error"><p><strong><?php _e('Payfluid Payment Gateway Disabled', 'woo-payfluid'); ?></strong>: <?php echo $this->msg; ?></p></div>

            <?php
        }
    }

    /**
     * Initialise Gateway Settings Form Fields.
     */
    public function init_form_fields() {

        $form_fields = array(
            'enabled' => array(
                'title' => __('Enable/Disable', 'woo-payfluid'),
                'label' => __('Enable Payfluid', 'woo-payfluid'),
                'type' => 'checkbox',
                'description' => __('Enable Payfluid as a payment option on the checkout page.', 'woo-payfluid'),
                'default' => 'no',
                'desc_tip' => true,
            ),
            'title' => array(
                'title' => __('Title', 'woo-payfluid'),
                'type' => 'text',
                'description' => __('This controls the payment method title which the user sees during checkout.', 'woo-payfluid'),
                //'default' => __('Debit/Credit Cards/Mobile Money/Bank Accounts', 'woo-payfluid'),
                'default' => __('Payfluid', 'woo-payfluid'),
                'desc_tip' => true,
            ),
            'description' => array(
                'title' => __('Description', 'woo-payfluid'),
                'type' => 'textarea',
                'description' => __('This controls the payment method description which the user sees during checkout.', 'woo-payfluid'),
                'default' => __('Make payment using your debit and credit cards, Mobile Money accounts as well as Bank Accounts', 'woo-payfluid'),
                'desc_tip' => true,
            ),
            'testmode' => array(
                'title' => __('Test mode', 'woo-payfluid'),
                'label' => __('Enable Test Mode', 'woo-payfluid'),
                'type' => 'checkbox',
                'description' => __('Test mode enables you to test payments before going live. <br />Once the LIVE MODE is enabled on your Payfluid account uncheck this.', 'woo-payfluid'),
                'default' => 'yes',
                'desc_tip' => true,
            ),
            'payment_page' => array(
                'title' => __('Payment Page', 'woo-payfluid'),
                'type' => 'select',
                'description' => __('Inline shows the payment popup on the page while Inline Embed shows the payment page directly on the page', 'woo-payfluid'),
                'default' => '',
                'desc_tip' => false,
                'options' => array(
                    '' => __('Select One', 'woo-payfluid'),
                    'inline' => __('Inline', 'woo-payfluid'),
                    'embed' => __('Inline Embed', 'woo-payfluid'),
                ),
            ),
            'test_api_key' => array(
                'title' => __('Test API Key', 'woo-payfluid'),
                'type' => 'text',
                'description' => __('Enter your Test API Key here', 'woo-payfluid'),
                'default' => '',
            ),
            'test_public_key' => array(
                'title' => __('Test Public Key', 'woo-payfluid'),
                'type' => 'text',
                'description' => __('Enter your Test Public Key here.', 'woo-payfluid'),
                'default' => '',
            ),
            'test_client_id' => array(
                'title' => __('Test Client ID', 'woo-payfluid'),
                'type' => 'text',
                'description' => __('Enter your Test Client ID here.', 'woo-payfluid'),
                'default' => '',
            ),
            'live_api_key' => array(
                'title' => __('Live API Key', 'woo-payfluid'),
                'type' => 'text',
                'description' => __('Enter your Live API Key here.', 'woo-payfluid'),
                'default' => '',
            ),
            'live_public_key' => array(
                'title' => __('Live Public Key', 'woo-payfluid'),
                'type' => 'text',
                'description' => __('Enter your Live Public Key here.', 'woo-payfluid'),
                'default' => '',
            ),
            'live_client_id' => array(
                'title' => __('Live Client ID', 'woo-payfluid'),
                'type' => 'text',
                'description' => __('Enter your Live Client ID here.', 'woo-payfluid'),
                'default' => '',
            ),
            'test_pay_url' => array(
                'title' => __('Test Payment URL', 'woo-payfluid'),
                'type' => 'text',
                'description' => __('Enter the test Payment URL here.', 'woo-payfluid'),
                'default' => '',
            ),
            'live_pay_url' => array(
                'title' => __('Live Payment URL', 'woo-payfluid'),
                'type' => 'text',
                'description' => __('Enter the live Payment URL here.', 'woo-payfluid'),
                'default' => '',
            ),
//            'pay_feedback_url' => array(
//                'title' => __('Response Redirect URL', 'woo-payfluid'),
//                'type' => 'text',
//                'description' => __('Enter the URL to redirect response to here.', 'woo-payfluid'),
//                'default' => '',
//            ),
            
            'custom_metadata' => array(
                'title' => __('Custom Metadata', 'woo-payfluid'),
                'label' => __('Enable Custom Metadata', 'woo-payfluid'),
                'type' => 'checkbox',
                'class' => 'wc-payfluid-metadata',
                'description' => __('If enabled, you will be able to send more information about the order to Payfluid.', 'woo-payfluid'),
                'default' => 'yes',
                'desc_tip' => true,
            ),
            'meta_order_id' => array(
                'title' => __('Order ID', 'woo-payfluid'),
                'label' => __('Send Order ID', 'woo-payfluid'),
                'type' => 'checkbox',
                'class' => 'wc-payfluid-meta-order-id',
                'description' => __('If checked, the Order ID will be sent to Payfluid', 'woo-payfluid'),
                'default' => 'yes',
                'desc_tip' => true,
            ),
            'meta_name' => array(
                'title' => __('Customer Name', 'woo-payfluid'),
                'label' => __('Send Customer Name', 'woo-payfluid'),
                'type' => 'checkbox',
                'class' => 'wc-payfluid-meta-name',
                'description' => __('If checked, the customer full name will be sent to Payfluid', 'woo-payfluid'),
                'default' => 'yes',
                'desc_tip' => true,
            ),
            'meta_email' => array(
                'title' => __('Customer Email', 'woo-payfluid'),
                'label' => __('Send Customer Email', 'woo-payfluid'),
                'type' => 'checkbox',
                'class' => 'wc-payfluid-meta-email',
                'description' => __('If checked, the customer email address will be sent to Payfluid', 'woo-payfluid'),
                'default' => 'yes',
                'desc_tip' => true,
            ),
            'meta_phone' => array(
                'title' => __('Customer Phone', 'woo-payfluid'),
                'label' => __('Send Customer Phone', 'woo-payfluid'),
                'type' => 'checkbox',
                'class' => 'wc-payfluid-meta-phone',
                'description' => __('If checked, the customer phone will be sent to Payfluid', 'woo-payfluid'),
                'default' => 'yes',
                'desc_tip' => true,
            ),
            'meta_billing_address' => array(
                'title' => __('Order Billing Address', 'woo-payfluid'),
                'label' => __('Send Order Billing Address', 'woo-payfluid'),
                'type' => 'checkbox',
                'class' => 'wc-payfluid-meta-billing-address',
                'description' => __('If checked, the order billing address will be sent to Payfluid', 'woo-payfluid'),
                'default' => 'no',
                'desc_tip' => true,
            ),
            'meta_shipping_address' => array(
                'title' => __('Order Shipping Address', 'woo-payfluid'),
                'label' => __('Send Order Shipping Address', 'woo-payfluid'),
                'type' => 'checkbox',
                'class' => 'wc-payfluid-meta-shipping-address',
                'description' => __('If checked, the order shipping address will be sent to Payfluid', 'woo-payfluid'),
                'default' => 'no',
                'desc_tip' => true,
            ),
            'meta_products' => array(
                'title' => __('Product(s) Purchased', 'woo-payfluid'),
                'label' => __('Send Product(s) Purchased', 'woo-payfluid'),
                'type' => 'checkbox',
                'class' => 'wc-payfluid-meta-products',
                'description' => __('If checked, the product(s) purchased will be sent to Payfluid', 'woo-payfluid'),
                'default' => 'no',
                'desc_tip' => true,
            ),
        );

        if ('GHS' !== get_woocommerce_currency() || 'GHC' !== get_woocommerce_currency()) {
            unset($form_fields['custom_gateways']);
        }

        $this->form_fields = $form_fields;
    }

    /**
     * Payment form on checkout page
     */
    public function payment_fields() {

        if ($this->description) {
            echo wpautop(wptexturize($this->description));
        }

        if (!$this->is_payfluid_testmode()) {
            if (!is_ssl()) {
                return;
            }
        }

    }

    /**
     * Outputs scripts used for payfluid payment.
     */
    public function payment_scripts() {

        if (!is_checkout_pay_page()) {
            return;
        }

        if ($this->enabled === 'no') {
            return;
        }

        $order_key = urldecode($_GET['key']);
        $order_id = absint(get_query_var('order-pay'));

        $order = wc_get_order($order_id);

        $payment_method = method_exists($order, 'get_payment_method') ? $order->get_payment_method() : $order->payment_method;

        if ($this->id !== $payment_method) {
            return;
        }
        $suffix = '';

        wp_enqueue_script('jquery');

        wp_enqueue_script('payfluid', plugins_url('assets/js/payfluid-oln' . $suffix . '.js', WC_PAYFLUID_MAIN_FILE), array('jquery'), WC_PAYFLUID_VERSION, false);

        wp_enqueue_script('wc_payfluid', plugins_url('assets/js/payfluid' . $suffix . '.js', WC_PAYFLUID_MAIN_FILE), array('jquery', 'payfluid'), WC_PAYFLUID_VERSION, false);


        $payfluid_params = array(
            'key' => $this->public_key,
        );


        if (is_checkout_pay_page() && get_query_var('order-pay')) {

            $email = method_exists($order, 'get_billing_email') ? $order->get_billing_email() : $order->billing_email;
            $amount = $order->get_total() * 1; // * 100;
            //$txnref = $order_id . '_' . time();
            // = $order_id . '';
            $txnref = $this->get_txn_ref($order_id);
            $the_order_id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;
            $the_order_key = method_exists($order, 'get_order_key') ? $order->get_order_key() : $order->order_key;
            $other_info = '';

            if ($the_order_id == $order_id && $the_order_key == $order_key) {

                $payment_link = get_post_meta($order_id, '_payment_link', true);

                $payfluid_params['pay_url'] = $payment_link;
                $payfluid_params['datetime'] = time();
                $payfluid_params['email'] = $email;
                $payfluid_params['amount'] = $amount;
                $payfluid_params['reference'] = $txnref;
                $payfluid_params['pay_page_type'] = $this->payment_page;
                $other_info .= $this->payment_page . ' | ';
                $payfluid_params['currency'] = get_woocommerce_currency();
            }


            if ($this->meta_order_id) {
                $other_info .= $order_id . ' | ';
            }

            if ($this->meta_name) {
                $first_name = method_exists($order, 'get_billing_first_name') ? $order->get_billing_first_name() : $order->billing_first_name;
                $last_name = method_exists($order, 'get_billing_last_name') ? $order->get_billing_last_name() : $order->billing_last_name;

                $payfluid_params['name'] = $first_name . ' ' . $last_name;
            }

            if ($this->meta_email) {
                $payfluid_params['email'] = $email;
            }

            if ($this->meta_phone) {
                $billing_phone = method_exists($order, 'get_billing_phone') ? $order->get_billing_phone() : $order->billing_phone;

                $payfluid_params['mobile'] = $billing_phone;
            }

            if ($this->meta_products) {

                $line_items = $order->get_items();
                $products = '';

                foreach ($line_items as $item_id => $item) {
                    $name = $item['name'];
                    $quantity = $item['qty'];
                    $products .= $name . ' (Qty: ' . $quantity . ')';
                    $products .= ' | ';
                }

                $products = rtrim($products, ' | ');
                $payfluid_params['descr'] = $products;
                $other_info .= $products . ' | ';
            }

            if ($this->meta_billing_address) {

                $billing_address = $order->get_formatted_billing_address();
                $billing_address = esc_html(preg_replace('#<br\s*/?>#i', ', ', $billing_address));
                $other_info .= $billing_address . ' | ';
            }

            if ($this->meta_shipping_address) {

                $shipping_address = $order->get_formatted_shipping_address();
                $shipping_address = esc_html(preg_replace('#<br\s*/?>#i', ', ', $shipping_address));

                if (empty($shipping_address)) {

                    $billing_address = $order->get_formatted_billing_address();
                    $billing_address = esc_html(preg_replace('#<br\s*/?>#i', ', ', $billing_address));

                    $shipping_address = $billing_address;
                }
                $other_info .= $shipping_address . ' | ';
            }
            $payfluid_params['otherInfo'] = $other_info;

            update_post_meta($order_id, '_payfluid_txn_ref', $txnref);
        }

        wp_localize_script('wc_payfluid', 'wc_payfluid_params', $payfluid_params);
    }

    /**
     * Load admin scripts.
     */
    public function admin_scripts() {

        if ('woocommerce_page_wc-settings' !== get_current_screen()->id) {
            return;
        }
        $payfluid_admin_params = array(
            'plugin_url' => WC_PAYFLUID_URL,
        );

        wp_localize_script('wc_payfluid_admin', 'wc_payfluid_admin_params', $payfluid_admin_params);
    }

    /**
     * Process the payment.
     *
     * @param int $order_id
     *
     * @return array|void
     */
    public function process_payment($order_id) {

        $order = wc_get_order($order_id);
        $status = $this->process_create_payment($order_id);
        if (!empty($status)) {

            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true),
            );
        }
        
    }
    
    /**
     * Displays the payment page.
     *
     * @param $order_id
     */
    public function receipt_page($order_id) {

        $order = wc_get_order($order_id);
        $payment_link = get_post_meta($order_id, '_payment_link', true);

        if ('embed' === $this->payment_page) {

            echo '<p style="text-align: center; font-weight: bold;">' . __('Thank you for your order, please make payment below using Payfluid.', 'woo-payfluid') . '</p>';

            echo '<div id="payfluidWooCommerceEmbedContainer" style="height: 700px;"></div>';

            echo '<div id="payfluid_form"><form id="order_review" method="post" action="' . WC()->api_request_url('WC_Gateway_Payfluid') . '"></form><a href="' . esc_url($order->get_cancel_order_url()) . '" style="text-align:center; color: #EF3315; display: block; outline: none;">' . __('Cancel order &amp; restore cart', 'woo-payfluid') . '</a></div>';
//            echo '<div id="payfluid_form"><form id="order_review" method="post" action="' . $payment_link . '"></form><a href="' . esc_url($order->get_cancel_order_url()) . '" style="text-align:center; color: #EF3315; display: block; outline: none;">' . __('Cancel order &amp; restore cart', 'woo-payfluid') . '</a></div>';
        } else {

            echo '<p>' . __('Thank you for your order, please click the button below to pay with Payfluid.', 'woo-payfluid') . '</p>';

            echo '<div id="payfluid_form"><form id="order_review" method="post" action="' . WC()->api_request_url('WC_Gateway_Payfluid') . '"></form><button class="button alt" id="payfluid-payment-button">' . __('Make Payment', 'woo-payfluid') . '</button> <a class="button cancel" href="' . esc_url($order->get_cancel_order_url()) . '">' . __('Cancel order &amp; restore cart', 'woo-payfluid') . '</a></div>';
//            echo '<div id="payfluid_form"><form id="order_review" method="post" action="' . $payment_link . '"></form><button class="button alt" id="payfluid-payment-button">' . __('Make Payment', 'woo-payfluid') . '</button> <a class="button cancel" href="' . esc_url($order->get_cancel_order_url()) . '">' . __('Cancel order &amp; restore cart', 'woo-payfluid') . '</a></div>';
        }
    }

    /**
     * Verify Payfluid payment.
     */
    public function verify_payfluid_transaction() {
        @ob_clean();
        //if (isset($_REQUEST['payfluid_txnref'])) {
        if (isset($_REQUEST['payfluid_resp'])) {
            $payfluid_resp_redirect_msg = $_REQUEST['payfluid_resp'] . '';
            //wc_add_notice('get to verifytransaction ::: ' . $payfluid_resp_redirect_msg, 'error');

            $json_rsp = urldecode($payfluid_resp_redirect_msg);
            //wc_add_notice('decoded url ::: ' .$json_rsp, 'error');

            $payfluid_response_json = json_decode($json_rsp);

            $rsp_sign = $payfluid_response_json->aapf_txn_signature;
            //wc_add_notice('signature ::: ' . $rsp_sign, 'error');

            ksort($payfluid_response_json);
            $hash_data = '';
            foreach ($payfluid_response_json as $sorted_key => $sorted_val) {
                if ($sorted_key != 'aapf_txn_signature') {
                    if ($sorted_key == 'aapf_txn_gw_sc' || $sorted_key == 'aapf_txn_sc_msg') {
                        //$hash_data .= str_replace(' ', '+', $sorted_val);
                        $hash_data .= $sorted_val;
                    } else {
                        $hash_data .= $sorted_val;
                    }
                }
            }
            //wc_add_notice('$hash_data ::: ' . $hash_data, 'error');

            $cust_ref = $payfluid_response_json->aapf_txn_cref;
            //wc_add_notice('$cust_ref ::: ' . $cust_ref, 'error');

            $order_details = explode('.', $cust_ref);
    
            $order_id = (int) $order_details[0];
            $order = wc_get_order($order_id);

            $session_id = get_post_meta($order_id, '_session_id', true);

            //wc_add_notice('session kept ::: ' . $session_id, 'error');

            $hmac_key = md5($session_id);
            $full_data_hash = hash_hmac('sha256', $hash_data, $hmac_key);

            //wc_add_notice('sent hash ::: ' . $rsp_sign . ' ,calc hash ::: ' . $full_data_hash, 'error');

            //if (!is_wp_error($request) && 200 === wp_remote_retrieve_response_code($request)) {
            if (strcasecmp($rsp_sign, $full_data_hash) == 0) {
                //if('1' == '1'){
                //$payfluid_response = json_decode(wp_remote_retrieve_body($request));
                $sc = $payfluid_response_json->aapf_txn_sc;
                //wc_add_notice('order status code ::: ' . $sc, 'error');
                if ('0' == $sc) {

                    if (in_array($order->get_status(), array('processing', 'completed', 'on-hold'))) {

                        wp_redirect($this->get_return_url($order));

                        exit;
                    }

                    $order_total = $order->get_total();
                    $order_currency = method_exists($order, 'get_currency') ? $order->get_currency() : $order->get_order_currency();
                    $currency_symbol = get_woocommerce_currency_symbol($order_currency);
                    $amount_paid = $payfluid_response_json->aapf_txn_amt;
                    $payfluid_ref = $payfluid_response_json->aapf_txn_ref;
                    $cur_sent = $payfluid_response_json->aapf_txn_currency;
                    $payment_currency = strtoupper($cur_sent);
                    $gateway_symbol = get_woocommerce_currency_symbol($payment_currency);

                    // check if the amount paid is equal to the order amount.
                    if ($amount_paid < $order_total) {

                        $order->update_status('on-hold', '');

                        add_post_meta($order_id, '_transaction_id', $payfluid_ref, true);

                        $notice = sprintf(__('Thank you for shopping with us.%1$sYour payment transaction was successful, but the amount paid is not the same as the total order amount.%2$sYour order is currently on hold.%3$sKindly contact us for more information regarding your order and payment status.', 'woo-payfluid'), '<br />', '<br />', '<br />');
                        $notice_type = 'notice';

                        // Add Customer Order Note
                        $order->add_order_note($notice, 1);

                        // Add Admin Order Note
                        $admin_order_note = sprintf(__('<strong>Look into this order</strong>%1$sThis order is currently on hold.%2$sReason: Amount paid is less than the total order amount.%3$sAmount Paid was <strong>%4$s (%5$s)</strong> while the total order amount is <strong>%6$s (%7$s)</strong>%8$s<strong>Payfluid Transaction Reference:</strong> %9$s', 'woo-payfluid'), '<br />', '<br />', '<br />', $currency_symbol, $amount_paid, $currency_symbol, $order_total, '<br />', $payfluid_ref);
                        $order->add_order_note($admin_order_note);

                        function_exists('wc_reduce_stock_levels') ? wc_reduce_stock_levels($order_id) : $order->reduce_order_stock();

                        wc_add_notice($notice, $notice_type);
                    } else {

                        if ($payment_currency !== $order_currency) {

                            $order->update_status('on-hold', '');

                            update_post_meta($order_id, '_transaction_id', $payfluid_ref);

                            $notice = sprintf(__('Thank you for shopping with us.%1$sYour payment was successful, but the payment currency is different from the order currency.%2$sYour order is currently on-hold.%3$sKindly contact us for more information regarding your order and payment status.', 'woo-payfluid'), '<br />', '<br />', '<br />');
                            $notice_type = 'notice';

                            // Add Customer Order Note
                            $order->add_order_note($notice, 1);

                            // Add Admin Order Note
                            $admin_order_note = sprintf(__('<strong>Look into this order</strong>%1$sThis order is currently on hold.%2$sReason: Order currency is different from the payment currency.%3$sOrder Currency is <strong>%4$s (%5$s)</strong> while the payment currency is <strong>%6$s (%7$s)</strong>%8$s<strong>Payfluid Transaction Reference:</strong> %9$s', 'woo-payfluid'), '<br />', '<br />', '<br />', $order_currency, $currency_symbol, $payment_currency, $gateway_symbol, '<br />', $payfluid_ref);
                            $order->add_order_note($admin_order_note);

                            function_exists('wc_reduce_stock_levels') ? wc_reduce_stock_levels($order_id) : $order->reduce_order_stock();

                            wc_add_notice($notice, $notice_type);
                        } else {

                            $order->payment_complete($payfluid_ref);
                            $order->add_order_note(sprintf(__('Payment via Payfluid successful (Transaction Reference: %s)', 'woo-payfluid'), $payfluid_ref));
                        }
                    }
                    

                    wc_empty_cart();
                } else {
                    $order->update_status('failed', __('Payment was declined by Payfluid. ('.$payfluid_response_json->aapf_txn_sc.'-'.$payfluid_response_json->aapf_txn_gw_sc.')', 'woo-payfluid'));
                }
            }

            wp_redirect($this->get_return_url($order));
            exit;
        }

        wp_redirect(wc_get_page_permalink('cart'));
        exit;
    }

    /**
     * Process Webhook.
     */
    public function process_webhooks() {

        if (( strtoupper($_SERVER['REQUEST_METHOD']) != 'POST')) {
            exit;
        }

        $json = file_get_contents('php://input');

        // validate event do all at once to avoid timing attack.
//        if ($_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] !== hash_hmac('sha512', $json, $this->api_key)) {
//            exit;
//        }
//        $event = json_decode($json);
        sleep(10);
        $payfluid_response_json = json_decode($json);
        $rsp_sign = $payfluid_response_json->aapf_txn_signature;
        ksort($payfluid_response_json);
        $hash_data = '';
        foreach ($payfluid_response_json as $sorted_key => $sorted_val) {
            if ($sorted_key != 'aapf_txn_signature') {
                if ($sorted_key == 'aapf_txn_gw_sc' || $sorted_key == 'aapf_txn_sc_msg') {
                    //$hash_data .= str_replace(' ', '+', $sorted_val);
                    $hash_data .= $sorted_val;
                } else {
                    $hash_data .= $sorted_val;
                }
            }
        }
        $cust_ref = $payfluid_response_json->aapf_txn_cref;
        
        $order_details = explode('.', $cust_ref);
        $order_id = (int) $order_details;
        //$order = wc_get_order($order_id);
        $session_id = get_post_meta($order_id, '_session_id', true);

        $hmac_key = md5($session_id);
        $full_data_hash = hash_hmac('sha256', $hash_data, $hmac_key);
        if (strcasecmp($rsp_sign, $full_data_hash) == 0) {
            exit;
        }

        $sc = $payfluid_response_json->aapf_txn_sc;
        
        if ('0' == $sc) {

            sleep(10);
            

            $order = wc_get_order($order_id);

            $payfluid_txn_ref = get_post_meta($order_id, '_payfluid_txn_ref', true);

            if ($cust_ref != $payfluid_txn_ref) {
                exit;
            }

            http_response_code(200);

            if (in_array($order->get_status(), array('processing', 'completed', 'on-hold'))) {
                exit;
            }
            

            $order_currency = method_exists($order, 'get_currency') ? $order->get_currency() : $order->get_order_currency();

            $currency_symbol = get_woocommerce_currency_symbol($order_currency);

            $order_total = $order->get_total();

            $amount_paid = $payfluid_response_json->aapf_txn_amt;

            $payfluid_ref = $payfluid_response_json->aapf_txn_ref;

            $payment_currency = strtoupper($payfluid_response_json->aapf_txn_currency);

            $gateway_symbol = get_woocommerce_currency_symbol($payment_currency);

            // check if the amount paid is equal to the order amount.
            if ($amount_paid < $order_total) {

                $order->update_status('on-hold', '');

                add_post_meta($order_id, '_transaction_id', $payfluid_ref, true);

                $notice = sprintf(__('Thank you for shopping with us.%1$sYour payment transaction was successful, but the amount paid is not the same as the total order amount.%2$sYour order is currently on hold.%3$sKindly contact us for more information regarding your order and payment status.', 'woo-payfluid'), '<br />', '<br />', '<br />');
                $notice_type = 'notice';

                // Add Customer Order Note.
                $order->add_order_note($notice, 1);

                // Add Admin Order Note.
                $admin_order_note = sprintf(__('<strong>Look into this order</strong>%1$sThis order is currently on hold.%2$sReason: Amount paid is less than the total order amount.%3$sAmount Paid was <strong>%4$s (%5$s)</strong> while the total order amount is <strong>%6$s (%7$s)</strong>%8$s<strong>Payfluid Transaction Reference:</strong> %9$s', 'woo-payfluid'), '<br />', '<br />', '<br />', $currency_symbol, $amount_paid, $currency_symbol, $order_total, '<br />', $payfluid_ref);
                $order->add_order_note($admin_order_note);

                function_exists('wc_reduce_stock_levels') ? wc_reduce_stock_levels($order_id) : $order->reduce_order_stock();

                wc_add_notice($notice, $notice_type);

                wc_empty_cart();
            } else {

                if ($payment_currency !== $order_currency) {

                    $order->update_status('on-hold', '');

                    update_post_meta($order_id, '_transaction_id', $payfluid_ref);

                    $notice = sprintf(__('Thank you for shopping with us.%1$sYour payment was successful, but the payment currency is different from the order currency.%2$sYour order is currently on-hold.%3$sKindly contact us for more information regarding your order and payment status.', 'woo-payfluid'), '<br />', '<br />', '<br />');
                    $notice_type = 'notice';

                    // Add Customer Order Note.
                    $order->add_order_note($notice, 1);

                    // Add Admin Order Note.
                    $admin_order_note = sprintf(__('<strong>Look into this order</strong>%1$sThis order is currently on hold.%2$sReason: Order currency is different from the payment currency.%3$sOrder Currency is <strong>%4$s (%5$s)</strong> while the payment currency is <strong>%6$s (%7$s)</strong>%8$s<strong>Payfluid Transaction Reference:</strong> %9$s', 'woo-payfluid'), '<br />', '<br />', '<br />', $order_currency, $currency_symbol, $payment_currency, $gateway_symbol, '<br />', $payfluid_ref);
                    $order->add_order_note($admin_order_note);

                    function_exists('wc_reduce_stock_levels') ? wc_reduce_stock_levels($order_id) : $order->reduce_order_stock();

                    wc_add_notice($notice, $notice_type);
                } else {
                    
                    $order->update_status('wc-processing');

                    $order->payment_complete($payfluid_ref);

                    $order->add_order_note(sprintf(__('Payment via Payfluid successful (Transaction Reference: %s)', 'woo-payfluid'), $payfluid_ref));

                    wc_empty_cart();
                }
            }

            exit;
        }

        exit;
    }
    

    /**
     * Checks if WC version is less than passed in version.
     *
     * @param string $version Version to check against.
     *
     * @return bool
     */
    public static function is_wc_lt($version) {
        return version_compare(WC_VERSION, $version, '<');
    }

    /**
     * Process payment ref creation.
     *
     * @param $order_id
     *
     * @return bool
     */
    public function process_create_payment($order_id) {
        if ($order_id) {
            //wc_add_notice('Order Id: ' . $order_id, 'error');
            $payfluid_url = $this->pay_url . '/payfluid/ext/api/getPayLink';

            $secure_keys = $this->process_secure_corridor();

            if (isset($secure_keys) && !empty($secure_keys)) {
                $sec_cred = explode('.', $secure_keys);
                $session_id = $sec_cred[0];
                $encry_pub_key = $sec_cred[1];
                $hash_mac_key = $sec_cred[2];

                $order = wc_get_order($order_id);

                $other_info = '';
                $email = method_exists($order, 'get_billing_email') ? $order->get_billing_email() : $order->billing_email;
                $order_amount_ = method_exists($order, 'get_total') ? $order->get_total() : $order->order_total;
                $amount = $order_amount_ * 1; //$order_amount_ * 100;
                //$datetime = date('YmdHisB');
                //$txnref = $order_id . '_' . time();
                //$txnref = $order_id . '_' . date('His');
                //$txnref = $order_id . '';
                $txnref = $this->get_txn_ref($order_id);
                $the_order_id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;
                $the_order_key = method_exists($order, 'get_order_key') ? $order->get_order_key() : $order->order_key;
                $currency = get_woocommerce_currency();
                $other_info .= '$order_id=' . $order_id . '|$the_order_id=' . $the_order_id . '|$the_order_key=' . $the_order_key . '|';

                $first_name = method_exists($order, 'get_billing_first_name') ? $order->get_billing_first_name() : $order->billing_first_name;
                $last_name = method_exists($order, 'get_billing_last_name') ? $order->get_billing_last_name() : $order->billing_last_name;

                $full_name = $first_name . ' ' . $last_name;
                $billing_phone = method_exists($order, 'get_billing_phone') ? $order->get_billing_phone() : $order->billing_phone;

                if(!(strpos($billing_phone, "233") === 0)){
                    $billing_phone = '+233'.substr($billing_phone,1);
                }else if((strpos($billing_phone, "233") === 0)){
                    $billing_phone = '+'.$billing_phone;
                }
                
                $line_items = $order->get_items();
                $products = '';
                foreach ($line_items as $item_id => $item) {
                    $name = $item['name'];
                    $quantity = $item['qty'];
                    $products .= $name . ' (Qty: ' . $quantity . ')';
                    $products .= '|';
                }
                $products = rtrim($products, '|');
                $purpose = $products;
                $other_info .= '$products=' . $products . '|';

                $billing_address = $order->get_formatted_billing_address();
                $billing_address = esc_html(preg_replace('#<br\s*/?>#i', ', ', $billing_address));
                $other_info .= '$billing_address=' . $billing_address . '|';

                $shipping_address = $order->get_formatted_shipping_address();
                $shipping_address = esc_html(preg_replace('#<br\s*/?>#i', ', ', $shipping_address));
                if (empty($shipping_address)) {
                    $billing_address = $order->get_formatted_billing_address();
                    $billing_address = esc_html(preg_replace('#<br\s*/?>#i', ', ', $billing_address));

                    $shipping_address = $billing_address;
                }
                $other_info .= '$shipping_address' . $shipping_address . '|';

                $body = array(
                    'name' => $full_name,
                    'email' => $email,
                    'mobile' => $billing_phone,
                    'descr' => $purpose,
                    'amount' => $amount,
                    'reference' => $txnref,
                    'trxStatusCallbackURL' => WC()->api_request_url('WC_Gateway_Payfluid'),
                    'lang' => 'en',
                    'currency' => $currency,
                    'session' => $session_id,
                    'responseRedirectURL' => WC()->api_request_url('Moak_WC_Payfluid_Webhook'),
                    //'responseRedirectURL' => $this->pay_feedback_url,
                    'otherInfo' => $other_info,
                    'datetime' => date('YmdHisB'),
//                    'customTxn' => '',
                );

                //$sorted_array = ksort($body);
                ksort($body);
                $hash_data = '';
                foreach ($body as $sorted_key => $sorted_val) {
                    $hash_data .= $sorted_val;
                }

                $full_data_hash = hash_hmac('sha256', $hash_data, $hash_mac_key);
                $header_signature = $this->encrypt($full_data_hash, $encry_pub_key);

                $headers = array(
                    'Content-Type' => 'application/json',
                    'signature' => $header_signature,
                );


                $args = array(
                    'body' => json_encode($body),
                    'headers' => $headers,
                    'timeout' => 60,
                );

//                wc_add_notice('$headers - ' . implode(",", $headers) . ' $body - ' . implode(",", $body) . ' $args - ' . implode(",", $args), 'error');
//                wc_add_notice('$args - ' . implode(",", $args), 'success');
                $request = wp_remote_post($payfluid_url, $args);



                if (!is_wp_error($request) && 200 === wp_remote_retrieve_response_code($request)) {

                    $payfluid_response = json_decode(wp_remote_retrieve_body($request));

                    if ('00' === $payfluid_response->result_code) {

                        $payment_link = $payfluid_response->webURL;
                        $payment_link_approval = $payfluid_response->approvalCode;
                        //wc_add_notice('$payfluid_response - ' . $payfluid_response->webURL, 'success');
                        add_post_meta($order_id, '_payment_link', $payment_link, true);
                        add_post_meta($order_id, '_payment_link_approval', $payment_link_approval);
                        add_post_meta($order_id, '_session_id', $session_id, true);

                        return $payment_link;
                    } else {
                        //if (isset($payfluid_response->result_message) && !empty($payfluid_response->result_message)) {
                        $order_notice = sprintf(__('Payment was declined by Payfluid. Reason: %s.', 'woo-payfluid'), $payfluid_response->result_code . '-' . $payfluid_response->result_message);
                        //}
                        wc_add_notice($order_notice, 'error');

                        return false;
                    }
                }
            } else {
                wc_add_notice(__('Secure keys not set. Transaction creation cannot be initiated', 'woo-payfluid'), 'error');
                return false;
            }
        } else {
            wc_add_notice(__('Payment Failed. No available order id', 'woo-payfluid'), 'error');
            return false;
        }
    }

    public function process_secure_corridor() {
        $payfluid_url = $this->pay_url . '/payfluid/ext/api/secureCredentials';
        $datetime = date('YmdHisB');
        $client_to_send = base64_encode($this->client_id);
        $data2crypt = $this->api_key . '.' . $datetime;
        $hdr_sign = $this->encrypt($data2crypt, $this->public_key);
        //wc_add_notice(('$payfluid_url: ' . $payfluid_url . ' - $data2crypt: ' . $data2crypt . ' - $client_to_send: ' . $client_to_send . ' - $hdr_sign: ' . $hdr_sign), 'error');

        if (!isset($hdr_sign) || empty($hdr_sign)) {
            $hdr_sign = 'noencrytiongotten';
        }

        $headers = array(
            'Content-Type' => 'application/json',
            'id' => $client_to_send,
            'apiKey' => $hdr_sign,
        );

        $body = array(
            'cmd' => 'getSecureParams',
            'datetime' => $datetime,
        );

        $args = array(
            'body' => json_encode($body),
            'headers' => $headers,
            'timeout' => 60,
        );

        //wc_add_notice($payfluid_url . '-' . implode(",", $headers) . '-' . implode(",", $body) . '-' . implode(",", $args), 'error');
        $request = wp_remote_post($payfluid_url, $args);
        //wc_add_notice(__(implode(",",$request) . ' - url - ' . $payfluid_url . ' - payload - ' . implode(",",$args), 'woo-payfluid'), 'error');
        if (!is_wp_error($request) && 200 === wp_remote_retrieve_response_code($request)) {

            $payfluid_response = json_decode(wp_remote_retrieve_body($request));

            if ('00' === $payfluid_response->resultCode) {
                $session_id = $payfluid_response->session;
                $kek = wp_remote_retrieve_header($request, 'kek');

                $corridor_keys = $session_id . '.' . $kek;

//                wc_add_notice(__('Corridor keys::: '.$corridor_keys, 'woo-payfluid'), 'error');

                return $corridor_keys;
            } else {
                $failed_notice = __('Unable to retrieve secure connection keys.(' . $payfluid_response->resultCode . '-' . $payfluid_response->resultMessage . ')', 'woo-payfluid');
                wc_add_notice($failed_notice, 'error');

                return false;
            }
        } else {
            wc_add_notice(__('Secure connection initiation failed.', 'woo-payfluid'), 'error');
            return false;
        }
    }

    
    public function encrypt($data, $public_key_passed_in) {
        try {

            $key = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($public_key_passed_in, 64, "\n", true) . "\n-----END PUBLIC KEY-----";


            $pk = openssl_pkey_get_public($key);
//            $pk = openssl_get_publickey($key);
            //wc_add_notice(__('Data : ' . $data . ' - key: ' . $key . ' - key2: ' . $pk, 'woo-payfluid'), 'error');
            $encrypted = '';
            if (openssl_public_encrypt($data, $encrypted, $pk)) {
                $enc_data = base64_encode($encrypted);
            } else {
                //echo 'error onencrypt ' . $data . ' - ' . $public_key_passed;
                throw new Exception('Unable to encrypt data. Perhaps it is bigger than the key size?::: ');
                //throw new Exception();
                //return new WP_Error('error', __('Cant secure data: ' . $data . 'key: ' . $public_key_passed , 'woo-payfluid'));
            }
        } catch (Exception $e) {
            wc_add_notice('Encrypt error : ' . $e->getMessage() . '???', 'error');
        }
//        wc_add_notice('Encrypted data : ' . $enc_data, 'error');
        return $enc_data;
    }

    public function decrypt22($data) {
        if (openssl_private_decrypt(base64_decode($data), $decrypted, $this->public_key)) {
            $data = $decrypted;
        } else {
            $data = '';
        }
        return $data;
    }

    public function is_payfluid_testmode() {
        $payfluid_settings = get_option('woocommerce_payfluid_settings');
        $test_mode = isset($payfluid_settings['testmode']) ? $payfluid_settings['testmode'] : '';

        if ('yes' === $test_mode) {
            return true;
        } else {
            return false;
        }
    }

    public function get_txn_ref($order_id) {
        $diff = 9 - strlen($order_id);
        $rdm = $this->GeraHash($diff);
        return $order_id . '.' . $rdm;
    }

    public function GeraHash($qtd) {
        //Under the string $Caracteres you write all the characters you want to be used to randomly generate the code.
        $Caracteres = 'A1aB2bC3cD4dE5eF6fG7gH8hI9jJ0jK1kL2lM3mO4oP5pQ6qR7rS8sT9tU0uV1vX2xW3wY4yZ5z';
        $QuantidadeCaracteres = strlen($Caracteres);
        $QuantidadeCaracteres--;

        $Hash = '';
        for ($x = 1; $x <= $qtd; $x++) {
            $Posicao = rand(0, $QuantidadeCaracteres);
            $Hash .= substr($Caracteres, $Posicao, 1);
        }
        return $Hash;
    }

}
